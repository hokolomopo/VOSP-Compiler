package tokens;

public enum TokenType{
    ID,
    KEYWORD,
    SYMBOL,
    LITERAL,
}
